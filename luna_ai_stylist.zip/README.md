# Luna AI Stylist — Telegram Bot

AI-стилист, использующий Google Gemini API.

## Установка зависимостей
pip install -r requirements.txt

## Запуск локально
python bot.py
